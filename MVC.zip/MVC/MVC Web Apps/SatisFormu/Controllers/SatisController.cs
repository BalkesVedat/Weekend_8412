﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace SatisFormu.Controllers
{
    public class SatisController : Controller
    {
        public IActionResult Index()
        {
            //  List<string> urunler = new List<string>();

            Dictionary<string, double> urunler = UrunYukle();

            ViewBag.UrunListesi = new SelectList(urunler.Keys);

            return View();
        }

        private static Dictionary<string, double> UrunYukle()
        {
            Dictionary<string, double> urunler = new Dictionary<string, double>();

            urunler.Add("Çikolata", 25);
            urunler.Add("Bisküvi", 50);
            urunler.Add("Ekmek", 20);
            urunler.Add("Yumurta", 5);
            return urunler;
        }

        [HttpPost]
        public IActionResult Hesapla(string urunAd, double miktar) 
        {
            Dictionary<string, double> urunListesi = UrunYukle();

            double fiyat = urunListesi[urunAd];

            double tutar = miktar * fiyat;

            double kdvTutar = tutar * 0.2;

            ViewBag.Fiyat = fiyat;
            ViewBag.Tutar = tutar;  
            ViewBag.KdvTutar = kdvTutar;
            ViewBag.Miktar = miktar;
            ViewBag.Urun = urunAd;

            return View();
        }
    }
}
