﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace HesapMakinesi.Controllers
{
    public class HesapController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Kullanici = "Vedat";

            OperatorListesiYukle("+");

            return View();
        }

        [HttpPost]
        public IActionResult Hesapla(double sayi1, string oprt, double sayi2)
        {
            double sonuc = 0;

            switch (oprt)
            {
                case "+":
                    sonuc = sayi1 + sayi2;
                    break;
                case "-":
                    sonuc = sayi1 - sayi2;
                    break;
                case "*":
                    sonuc = sayi1 * sayi2;
                    break;
                case "/":
                    if (sayi2 == 0)
                        sonuc = 0;
                    else
                        sonuc = sayi1 / sayi2;
                    break;
                default:
                    break;
            }

            ViewBag.Sonuc = sonuc.ToString(System.Globalization.CultureInfo.InvariantCulture);
            ViewBag.Sayi1 = sayi1;
            ViewBag.Sayi2 = sayi2;

            OperatorListesiYukle(oprt);

            return View("Index");

        }

        private void OperatorListesiYukle(string oprt)
        {
            List<string> oprtList = new List<string>();

            oprtList.Add("+");
            oprtList.Add("-");
            oprtList.Add("*");
            oprtList.Add("/");

            ViewBag.Oprt = new SelectList(oprtList, oprt);
        }
    }
}
