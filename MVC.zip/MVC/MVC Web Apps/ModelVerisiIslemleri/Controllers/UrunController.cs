﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ModelVerisiIslemleri.Models;

namespace ModelVerisiIslemleri.Controllers
{
    public class UrunController : Controller
    {
        // GET: UrunController
        public ActionResult Index()
        {
            List<Urun> UrunListesi = new List<Urun>();

            UrunListesi.Add(new Urun() { UrunAd = "Domates", Marka = "abc", Model = "Pembe", Fiyat = 35 });
            UrunListesi.Add(new Urun() { UrunAd = "Fare", Marka = "A4", Model = "x235", Fiyat = 2500 });
            UrunListesi.Add(new Urun() { UrunAd = "Bulaşık Deterjanı", Marka = "mintax", Model = "Domestos", Fiyat = 335 });
            UrunListesi.Add(new Urun() { UrunAd = "Ekmek", Marka = "Mercedes", Model = "Somun", Fiyat = 20 });
            UrunListesi.Add(new Urun() { UrunAd = "Şapka", Marka = "Adidas", Model = "Siyah", Fiyat = 500 });

            return View(UrunListesi);
        }

        // GET: UrunController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: UrunController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: UrunController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: UrunController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: UrunController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: UrunController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: UrunController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
