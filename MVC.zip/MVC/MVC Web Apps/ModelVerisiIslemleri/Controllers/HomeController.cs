using Microsoft.AspNetCore.Mvc;
using ModelVerisiIslemleri.Models;
using System.Diagnostics;

namespace ModelVerisiIslemleri.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
             string isim = "Vedat";

            return View("Index",isim);
        }

        public IActionResult Privacy()
        {

            return View();
        }

        public IActionResult Urunler() 
        { 
            List<Urun> UrunListesi = new List<Urun>();

            UrunListesi.Add(new Urun() { UrunAd = "Domates", Marka = "abc", Model = "Pembe", Fiyat = 35});
            UrunListesi.Add(new Urun() { UrunAd = "Fare", Marka = "A4", Model = "x235", Fiyat = 2500 });
            UrunListesi.Add(new Urun() { UrunAd = "Bula��k Deterjan�", Marka = "mintax", Model = "Domestos", Fiyat = 335 });
            UrunListesi.Add(new Urun() { UrunAd = "Ekmek", Marka = "Mercedes", Model = "Somun", Fiyat = 20 });
            UrunListesi.Add(new Urun() { UrunAd = "�apka", Marka = "Adidas", Model = "Siyah", Fiyat = 500 });

           // ViewBag.UrunListesi = UrunListesi;


            return View(UrunListesi);
        }






        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
